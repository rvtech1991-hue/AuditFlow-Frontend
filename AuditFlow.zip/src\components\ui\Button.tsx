import type { ButtonHTMLAttributes } from "react";

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "default" | "primary";
  size?: "default" | "small";
};

export function Button({ variant = "default", size = "default", className = "", ...props }: ButtonProps) {
  return <button className={`button ${variant === "primary" ? "primary" : ""} ${size === "small" ? "small" : ""} ${className}`} {...props} />;
}
