import { createContext, useContext, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { mockUser } from "../mock-data/auth";
import type { Role, User } from "../types";

type RoleContextValue = {
  user: User;
  role: Role;
  setRole: (role: Role) => void;
};

const RoleContext = createContext<RoleContextValue | undefined>(undefined);

export function RoleProvider({ children }: { children: ReactNode }) {
  const [role, setRole] = useState<Role>(mockUser.role);
  const user = useMemo(() => ({ ...mockUser, role }), [role]);

  return <RoleContext.Provider value={{ user, role, setRole }}>{children}</RoleContext.Provider>;
}

export function useRole() {
  const context = useContext(RoleContext);
  if (!context) {
    throw new Error("useRole must be used inside RoleProvider");
  }
  return context;
}
