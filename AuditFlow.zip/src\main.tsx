import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { AppShell } from "./components/layout/AppShell";
import { RoleProvider } from "./lib/RoleContext";
import { routes } from "./lib/routes";
import { PlaceholderPage } from "./pages/PlaceholderPage";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <RoleProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          {routes.map((route) => (
            <Route
              key={route.path}
              path={route.path}
              element={
                route.public ? (
                  <PlaceholderPage route={route} />
                ) : (
                  <AppShell>
                    <PlaceholderPage route={route} />
                  </AppShell>
                )
              }
            />
          ))}
        </Routes>
      </BrowserRouter>
    </RoleProvider>
  </React.StrictMode>,
);
