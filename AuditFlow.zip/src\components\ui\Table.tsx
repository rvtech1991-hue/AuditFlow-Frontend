import type { ReactNode } from "react";

type Column<T> = {
  key: keyof T | string;
  header: string;
  render?: (row: T) => ReactNode;
};

type TableProps<T> = {
  columns: Column<T>[];
  rows: T[];
};

export function Table<T extends Record<string, unknown>>({ columns, rows }: TableProps<T>) {
  return (
    <table className="grid-table">
      <thead>
        <tr>
          {columns.map((column) => (
            <th key={String(column.key)}>{column.header}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((row, index) => (
          <tr key={String(row.id ?? index)}>
            {columns.map((column) => (
              <td key={String(column.key)}>{column.render ? column.render(row) : String(row[column.key] ?? "")}</td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export function CellPerson({ initials, name, meta }: { initials: string; name: string; meta?: string }) {
  return (
    <span className="cell-person">
      <span className="avatar">{initials}</span>
      <span>
        {name}
        {meta ? <small style={{ display: "block", color: "var(--text-muted)", fontWeight: 500 }}>{meta}</small> : null}
      </span>
    </span>
  );
}
