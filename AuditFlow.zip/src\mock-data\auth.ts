import type { User } from "../types";

export const mockUser: User = {
  name: "Rakesh Kumar",
  email: "rakesh@auditflow.test",
  role: "Auditor",
  status: "Active",
};
